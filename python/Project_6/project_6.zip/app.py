''' Jamie Garcia CYOP 300 Section 6381 Project 6'''

from datetime import datetime
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def homepage():
    """The home page of the website."""
    current_time = datetime.now()
    return render_template('homepage.html', current_time=current_time)

@app.route('/about/')
def about():
    """The about page of the website."""
    return render_template('about.html')

@app.route('/peppers/')
def peppers():
    """The contact page of the website."""
    return render_template('peppers.html')
